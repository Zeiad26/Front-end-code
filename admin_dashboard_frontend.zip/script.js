function loadContent(module) {
    const content = document.getElementById('content');
    switch (module) {
        case 'ManageUserAccounts':
            content.innerHTML = `
                <h1>Manage User Accounts</h1>
                <table>
                    <tr>
                        <th>User ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>John Doe</td>
                        <td>john@example.com</td>
                        <td><button>Edit</button> <button>Delete</button></td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Jane Smith</td>
                        <td>jane@example.com</td>
                        <td><button>Edit</button> <button>Delete</button></td>
                    </tr>
                </table>
            `;
            break;
        case 'SystemMetrics':
            content.innerHTML = `
                <h1>System Metrics</h1>
                <p>Placeholder for system performance metrics...</p>
            `;
            break;
        case 'ModerateArticles':
            content.innerHTML = `
                <h1>Moderate Articles</h1>
                <p>Placeholder for flagged articles...</p>
            `;
            break;
        default:
            content.innerHTML = `
                <h1>Welcome to the Admin Dashboard</h1>
                <p>Select a module from the sidebar to get started.</p>
            `;
    }
}

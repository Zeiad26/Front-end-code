from flask import Flask, jsonify, request, send_from_directory

app = Flask(__name__)

# Sample data for demonstration
users = [{"id": 1, "name": "John Doe"}, {"id": 2, "name": "Jane Smith"}]
articles = [
    {"id": 1, "title": "Breaking News", "flagged": True},
    {"id": 2, "title": "Daily Update", "flagged": False},
]
news_sources = [{"id": 1, "name": "Source A"}, {"id": 2, "name": "Source B"}]
system_metrics = {"CPU_Usage": "45%", "RAM_Usage": "65%"}
admin_notifications = []
preferences = {"theme": "dark", "notifications": True}
sentiment_performance = {"accuracy": "87%", "precision": "90%"}
article_trends = {"trend_1": "Tech", "trend_2": "Health"}

@app.route("/")
def frontend():
    return send_from_directory(".", "index.html")

@app.route("/api/manage_users", methods=["GET", "POST", "PUT", "DELETE"])
def manage_users():
    global users
    if request.method == "GET":
        return jsonify({"users": users})
    elif request.method == "POST":
        new_user = request.json
        users.append(new_user)
        return jsonify({"status": "User added", "users": users})
    elif request.method == "PUT":
        updated_user = request.json
        for user in users:
            if user["id"] == updated_user["id"]:
                user.update(updated_user)
        return jsonify({"status": "User updated", "users": users})
    elif request.method == "DELETE":
        user_id = request.args.get("id", type=int)
        users = [user for user in users if user["id"] != user_id]
        return jsonify({"status": "User deleted", "users": users})

@app.route("/api/monitor_system", methods=["GET"])
def monitor_system():
    return jsonify(system_metrics)

@app.route("/api/moderate_articles", methods=["GET", "POST"])
def moderate_articles():
    global articles
    if request.method == "GET":
        flagged_articles = [article for article in articles if article["flagged"]]
        return jsonify({"flagged_articles": flagged_articles})
    elif request.method == "POST":
        review = request.json
        for article in articles:
            if article["id"] == review["id"]:
                article["flagged"] = False
        return jsonify({"status": "Article reviewed", "articles": articles})

@app.route("/api/classification_settings", methods=["PUT"])
def classification_settings():
    new_settings = request.json
    return jsonify({"status": "Classification settings updated", "settings": new_settings})

@app.route("/api/manage_sources", methods=["GET", "POST", "DELETE"])
def manage_sources():
    global news_sources
    if request.method == "GET":
        return jsonify({"sources": news_sources})
    elif request.method == "POST":
        new_source = request.json
        news_sources.append(new_source)
        return jsonify({"status": "Source added", "sources": news_sources})
    elif request.method == "DELETE":
        source_id = request.args.get("id", type=int)
        news_sources = [source for source in news_sources if source["id"] != source_id]
        return jsonify({"status": "Source deleted", "sources": news_sources})

@app.route("/api/adjust_preferences", methods=["PUT"])
def adjust_preferences():
    global preferences
    preferences.update(request.json)
    return jsonify({"status": "Preferences updated", "preferences": preferences})

@app.route("/api/sentiment_performance", methods=["GET"])
def sentiment_performance():
    return jsonify(sentiment_performance)

@app.route("/api/article_trends", methods=["GET"])
def article_trends():
    return jsonify(article_trends)

@app.route("/api/admin_notifications", methods=["POST"])
def admin_notifications():
    global admin_notifications
    notification = request.json
    admin_notifications.append(notification)
    return jsonify({"status": "Notification added", "notifications": admin_notifications})

@app.route("/api/usage_statistics", methods=["GET"])
def usage_statistics():
    stats = {"total_users": len(users), "total_articles": len(articles)}
    return jsonify({"usage_statistics": stats})

if __name__ == "__main__":
    app.run(debug=True)
